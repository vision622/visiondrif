'use client';

import { useEffect } from 'react';
import { toast } from 'sonner';
import { AlertTriangle, CircleDot, Radio } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FOUR_TRADE_LEGS, type FourTradeLeg, type FourTradeStakes, type FourTradeRoundLog } from '@/lib/types';

interface FourTradeBotPanelProps {
  isRunning: boolean;
  onStart: () => void;
  onStop: () => void;
  stakes: FourTradeStakes;
  onStakeChange: (leg: FourTradeLeg, value: string) => void;
  duration: number;
  onDurationChange: (value: number) => void;
  roundsFired: number;
  totalStaked: number;
  log: FourTradeRoundLog[];
  isFiring: boolean;
  startError: string | null;
  isConnected: boolean;
  isAuthenticated: boolean;
}

export function FourTradeBotPanel({
  isRunning,
  onStart,
  onStop,
  stakes,
  onStakeChange,
  duration,
  onDurationChange,
  roundsFired,
  totalStaked,
  log,
  isFiring,
  startError,
  isConnected,
  isAuthenticated,
}: FourTradeBotPanelProps) {
  useEffect(() => {
    if (startError) toast.error('Bot not started', { description: startError });
  }, [startError]);

  return (
    <Card className="shrink-0 border shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Radio className="h-4 w-4 text-primary" />
            Four-Trade Bot
          </CardTitle>
          {isRunning && (
            <Badge className="bg-buy-background text-buy-foreground gap-1.5 animate-pulse">
              <CircleDot className="h-3 w-3" />
              {isFiring ? 'Firing…' : 'Running'}
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          Fires Over 4, Under 4, Over 5 and Under 5 together on every tick, each with its own stake.
        </p>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5 text-xs text-amber-700 dark:text-amber-400">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
          <p>
            This places real trades automatically, one round every tick, for as long as it runs. Keep this
            tab open and watch your balance — stop the bot any time.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {FOUR_TRADE_LEGS.map(leg => (
            <div key={leg.key} className="space-y-1.5">
              <Label htmlFor={`stake-${leg.key}`} className="text-xs text-muted-foreground">
                {leg.label} stake
              </Label>
              <Input
                id={`stake-${leg.key}`}
                type="number"
                value={stakes[leg.key]}
                onChange={e => onStakeChange(leg.key, e.target.value)}
                onKeyDown={e => {
                  if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault();
                }}
                disabled={isRunning}
                min={0}
                step="0.01"
                labelRight="USD"
              />
            </div>
          ))}
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="bot-duration" className="text-xs text-muted-foreground">
            Contract duration
          </Label>
          <Input
            id="bot-duration"
            type="number"
            value={duration}
            onChange={e => {
              const val = parseInt(e.target.value, 10);
              if (!isNaN(val) && val > 0) onDurationChange(val);
            }}
            disabled={isRunning}
            min={1}
            step={1}
            labelRight="Ticks"
          />
        </div>

        <div className="flex items-center justify-between rounded-lg border border-border bg-muted/20 p-3 text-xs">
          <div>
            <p className="text-muted-foreground">Rounds fired</p>
            <p className="font-bold text-sm">{roundsFired}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Total staked</p>
            <p className="font-bold text-sm">{totalStaked.toFixed(2)} USD</p>
          </div>
        </div>

        <Button
          className="w-full h-10 rounded-full"
          variant={isRunning ? 'destructive' : 'buy'}
          disabled={!isRunning && (!isConnected || !isAuthenticated)}
          onClick={isRunning ? onStop : onStart}
        >
          {isRunning ? 'Stop Bot' : 'Start Bot'}
        </Button>
        {!isAuthenticated && (
          <p className="text-xs text-center text-muted-foreground">Log in to start the bot.</p>
        )}

        {log.length > 0 && (
          <div className="space-y-1.5">
            <p className="text-xs text-muted-foreground">Recent rounds</p>
            <div className="max-h-64 overflow-y-auto rounded-lg border border-border divide-y divide-border">
              {log.map(round => (
                <div key={round.id} className="p-2 text-xs space-y-1">
                  <div className="flex items-center justify-between text-muted-foreground">
                    <span>{new Date(round.time).toLocaleTimeString()}</span>
                    <span>
                      digit{' '}
                      <span className="inline-flex w-4 h-4 rounded-full bg-primary text-primary-foreground items-center justify-center text-[10px] font-bold">
                        {round.triggerDigit}
                      </span>
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                    {round.results.map(r => (
                      <div key={r.leg} className="flex items-center justify-between">
                        <span className="text-muted-foreground">
                          {FOUR_TRADE_LEGS.find(l => l.key === r.leg)?.label}
                        </span>
                        {r.status === 'success' ? (
                          <span className="text-buy-background font-medium">
                            #{r.contractId}
                          </span>
                        ) : (
                          <span className="text-destructive font-medium truncate max-w-[100px]" title={r.errorMessage}>
                            failed
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
